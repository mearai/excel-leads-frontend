import AuthTwoSteps from "@/app/components/authForms/AuthTwoSteps";
export const metadata = {
  title: "Verify Code",
};
export default function TwoSteps() {
  return <AuthTwoSteps />;
}
