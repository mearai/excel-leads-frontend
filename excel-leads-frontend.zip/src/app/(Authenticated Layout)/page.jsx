import React from "react";
import StatsDashboard from "./components/widgets/StatsDashboard";

export const metadata = {
  title: "Home",
};
const page = () => {
  return <StatsDashboard />;
};

export default page;
