import React from "react";
import CampaignsPage from "./campaignsPage";
export const metadata = {
  title: "Campaigns",
};
const page = () => {
  return <CampaignsPage />;
};

export default page;
