import React from "react";
import IpSettings from "./IpSettings";
export const metadata = {
  title: "Ip Settings",
};
const page = () => {
  return <IpSettings />;
};

export default page;
