import React from "react";
import UserActivity from "./UserActivity";
export const metadata = {
  title: "User Activity",
};
const page = () => {
  return <UserActivity />;
};

export default page;
