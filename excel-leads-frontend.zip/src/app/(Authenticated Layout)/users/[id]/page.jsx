import React from "react";
import UserStatsPage from "./UserStatsPage";
export const metadata = {
  title: "User Stats",
};
const page = () => {
  return <UserStatsPage />;
};

export default page;
