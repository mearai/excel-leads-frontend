import React from "react";
import UsersPage from "./UsersPage";
export const metadata = {
  title: "Users",
};
const page = () => {
  return <UsersPage />;
};

export default page;
