import React from "react";
import LeadsPage from "./LeadsPage";
export const metadata = {
  title: "Leads",
};

const page = () => {
  return <LeadsPage />;
};

export default page;
