import React from "react";
import LeadDetailsPage from "./LeadDetailsPage";
export const metadata = {
  title: "Lead Details",
};
const page = () => {
  return <LeadDetailsPage />;
};

export default page;
